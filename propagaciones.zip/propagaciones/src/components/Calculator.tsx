import { useEffect } from 'react';
import {
  Container,
  Typography,
  Button,
  Box,
  Paper,
  Grid,
} from '@mui/material';
import { z } from 'zod';
import { useForm, useWatch } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { usePropagationCalculatorStore } from '../store/CalculatorStore';
import ControlledNumberInput from './inputs/ControlledNumberInput';
import ControlledSelectorInput from './inputs/ControlledSelectorInput';
import {
  Scenario,
  LossModel,
  Tabulation,
  LineOfSight
} from '../models';
import {
  ESCENARIOS,
  LINE_OF_SIGHTS,
  LOSS_MODELS,
  TABULATIONS
} from '../config/constants';
import useValidationSchema from '../helpers/validationSchema';
import { calculatePropagation } from '../helpers/calculatePropagationTrayectory';
import PropagationResults from './sections/PropagationResult';

export default function Calculator() {
  const schema = useValidationSchema();
  type PropagationFormData = z.infer<typeof schema>;

  const {
    scenario,
    lossModel,
    lineOfSight,
    tabulation,
    frequency,
    frequencyLimits,
    distance2DOut,
    distance2DOutLimits,
    distance2DIn,
    distance2DInLimits,
    heightBS,
    heightBSLimits,
    heightUT,
    heightUTLimits,
    buildingHeight,
    buildingHeightLimits,
    streetWidth,
    streetWidthLimits,
    variableFrequency,
    variableFrequencyLimits,
    variableDistance,
    variableDistanceLimits,
    propagationResult,
    setScenario,
    setLossModel,
    setLineOfSight,
    setTabulation,
    setPropagationValues,
  } = usePropagationCalculatorStore();

  const { control, handleSubmit } = useForm<PropagationFormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      scenario: scenario || Scenario.RURAL_MACROCELL,
      lossModel: lossModel || LossModel.LOW_LOSSES,
      tabulation: tabulation || Tabulation.UNIC_VALUE,
      lineOfSight: lineOfSight || LineOfSight.LOS,
      variableFrequency,
      variableDistance,
      frequency,
      distance2DOut,
      distance2DIn,
      heightBS,
      heightUT,
      buildingHeight,
      streetWidth,
    },
  });

  const onSubmit = (data: PropagationFormData) => {
    console.log('Form submitted');
    console.log('data', data);

    // Usar setPropagationValues para actualizar los valores numéricos
    setPropagationValues({
      variableFrequency: tabulation === Tabulation.VARIABLE_FREQUENCY ? data.variableFrequency : undefined,
      variableDistance: tabulation === Tabulation.VARIABLE_DISTANCE ? data.variableDistance : undefined,
      frequency: data.frequency,
      distance2DOut: data.distance2DOut,
      distance2DIn: data.distance2DIn,
      heightBS: data.heightBS,
      heightUT: data.heightUT,
      buildingHeight: scenario === Scenario.RURAL_MACROCELL ? data.buildingHeight : undefined,
      streetWidth: scenario === Scenario.RURAL_MACROCELL ? data.streetWidth : undefined
    });

    calculatePropagation();
  };

  // Observamos cambios en los valores de los selectores
  const watchedScenario = useWatch({ control, name: 'scenario' });
  const watchedLossModel = useWatch({ control, name: 'lossModel' });
  const watchedTabulation = useWatch({ control, name: 'tabulation' });
  const watchedLineOfSight = useWatch({ control, name: 'lineOfSight' });

  // Actualizamos los valores en la store cuando cambian
  useEffect(() => {
    if (watchedScenario !== scenario) {
      setScenario(watchedScenario);
    }
  }, [watchedScenario, scenario, setScenario]);

  useEffect(() => {
    if (watchedLossModel !== lossModel) {
      setLossModel(watchedLossModel);
    }
  }, [watchedLossModel, lossModel, setLossModel]);

  useEffect(() => {
    if (watchedTabulation !== tabulation) {
      setTabulation(watchedTabulation);
    }
  }, [watchedTabulation, tabulation, setTabulation]);

  useEffect(() => {
    if (watchedLineOfSight !== lineOfSight) {
      setLineOfSight(watchedLineOfSight);
    }
  }, [watchedLineOfSight, lineOfSight, setLineOfSight]);

  return (
    <Container maxWidth="md">
      <Paper elevation={3} sx={{ p: 4, mt: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom align="center">
          Calculadora de Propagación Trayecto 5G
        </Typography>
        <Box component="form" noValidate autoComplete="off" sx={{ mt: 3 }} onSubmit={handleSubmit(onSubmit)}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <ControlledSelectorInput
                name="scenario"
                control={control}
                label="Escenario"
                options={ESCENARIOS}
              />
              <ControlledSelectorInput
                name="lossModel"
                control={control}
                label="Modelo de Pérdidas"
                options={LOSS_MODELS}
              />
              <ControlledSelectorInput
                name="tabulation"
                control={control}
                label="Tabulación"
                options={TABULATIONS}
              />
              <ControlledSelectorInput
                name="lineOfSight"
                control={control}
                label="Línea de Vista"
                options={LINE_OF_SIGHTS}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              {Tabulation.VARIABLE_FREQUENCY === tabulation && (
              <ControlledNumberInput
                name="variableFrequency"
                control={control}
                fullWidth
                margin="normal"
                minValue={variableFrequencyLimits.min}
                maxValue={variableDistanceLimits.max}
                step={0.1}
                unit="GHz"
                labelTemplate={(min, max) => `Frecuencias Variables (${min} ≤ f ≤ ${max})`}
              />)}
              {Tabulation.VARIABLE_DISTANCE === tabulation && (
              <ControlledNumberInput
                name="variableDistance"
                control={control}
                fullWidth
                margin="normal"
                minValue={variableDistanceLimits.min}
                maxValue={variableDistanceLimits.max}
                step={0.1}
                unit="m"
                labelTemplate={(min, max, unit) => `Distancias Variables (${min}${unit} ≤ m ≤ ${max}${unit})`}
              />)}
              <ControlledNumberInput
                name="frequency"
                control={control}
                fullWidth
                margin="normal"
                minValue={frequencyLimits.min}
                maxValue={frequencyLimits.max}
                step={0.1}
                unit="GHz"
                labelTemplate={(min, max) => `Frecuencia (${min} ≤ fc ≤ ${max})`}
              />
              <ControlledNumberInput
                name="distance2DOut"
                control={control}
                fullWidth
                margin="normal"
                minValue={distance2DOutLimits.min}
                maxValue={distance2DOutLimits.max}
                step={0.1}
                unit="m"
                labelTemplate={(min, max, unit) => `Distancia 2D-out (${min}${unit} ≤ d_out ≤ ${max}${unit})`}
              />
              <ControlledNumberInput
                name="distance2DIn"
                control={control}
                fullWidth
                margin="normal"
                minValue={distance2DInLimits.min}
                maxValue={distance2DInLimits.max}
                step={0.1}
                unit="m"
                labelTemplate={(min, max, unit) => `Distancia 2D-in (${min}${unit} ≤ d_in ≤ ${max}${unit})`}
              />
              <ControlledNumberInput
                name="heightBS"
                control={control}
                fullWidth
                margin="normal"
                minValue={heightBSLimits.min}
                maxValue={heightBSLimits.max}
                step={0.1}
                unit="m"
                labelTemplate={(min, max, unit) => `Altura BS (${min}${unit} ≤ hBS ≤ ${max}${unit})`}
              />
              <ControlledNumberInput
                name="heightUT"
                control={control}
                fullWidth
                margin="normal"
                minValue={heightUTLimits.min}
                maxValue={heightUTLimits.max}
                step={0.1}
                unit="m"
                labelTemplate={(min, max, unit) => `Altura UT (${min}${unit} ≤ hUT ≤ ${max}${unit})`}
              />
              { scenario === Scenario.RURAL_MACROCELL && <>
              <ControlledNumberInput
                name="buildingHeight"
                control={control}
                fullWidth
                margin="normal"
                minValue={buildingHeightLimits.min}
                maxValue={buildingHeightLimits.max}
                step={0.1}
                unit="m"
                labelTemplate={(min, max, unit) => `Altura del Edificio (${min}${unit} ≤ h ≤ ${max}${unit})`}
              />
              <ControlledNumberInput
                name="streetWidth"
                control={control}
                fullWidth
                margin="normal"
                minValue={streetWidthLimits.min}
                maxValue={streetWidthLimits.max}
                step={0.1}
                unit="m"
                labelTemplate={(min, max, unit) => `Ancho de la Calle (${min}${unit} ≤ w ≤ ${max}${unit})`}
              />
              </>}
            </Grid>
          </Grid>
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
            <Button
              type="submit"
              variant="contained"
              color="primary"
              size="large"
              sx={{ maxWidth: '200px', width: '100%' }}
            >
              Calcular
            </Button>
          </Box>
        </Box>
        {propagationResult && <PropagationResults propagationResult={propagationResult} />}
      </Paper>
    </Container>
  );
}