import { Control, Controller, FieldValues, Path } from 'react-hook-form';
import MuiSelectorInput from './MuiSelectorInput';

interface Option {
    id: string | number;
    label: string;
}

interface ControlledSelectorInputProps<T extends FieldValues> {
    name: Path<T>;
    control: Control<T>;
    label: string;
    options: Option[];
}

function ControlledSelectorInput<T extends FieldValues>({
    name,
    control,
    label,
    options,
}: ControlledSelectorInputProps<T>) {
    return (
        <Controller
            name={name}
            control={control}
            render={({ field, fieldState: { error } }) => (
                <MuiSelectorInput
                    {...field}
                    label={label}
                    options={options}
                    error={!!error}
                />
            )}
        />
    );
}

export default ControlledSelectorInput;