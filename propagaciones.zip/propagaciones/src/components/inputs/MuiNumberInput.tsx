import React, { forwardRef } from 'react';
import { TextField, Typography, styled, TextFieldProps } from '@mui/material';

const BlueAdornment = styled(Typography)(({ theme }) => ({
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.primary.contrastText,
    padding: theme.spacing(0, 1),
    borderTopRightRadius: theme.shape.borderRadius + 'px',
    borderBottomRightRadius: theme.shape.borderRadius + 'px',
    display: 'flex',
    flex: '1',
    alignItems: 'center',
    justifyContent: 'center',
    fontWeight: 'bold',
    height: '40px',
    minWidth: '30px',
}));

const StyledTextField = styled(TextField)(() => ({
    '& .MuiOutlinedInput-root': {
        padding: 0,
        display: 'flex',
    }
}));

export interface MuiNumberInputProps extends Omit<TextFieldProps, 'type'> {
    minValue: number;
    maxValue: number;
    step: number;
    unit: string;
    labelTemplate: (minValue?: number, maxValue?: number, unit?: string) => string;
}

const MuiNumberInput = forwardRef<HTMLDivElement, MuiNumberInputProps>(({ 
    minValue,
    maxValue,
    step,
    unit,
    labelTemplate,
    onChange,
    value,
    ...props
}, ref) => {
    const label = labelTemplate(minValue, maxValue, unit);

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const newValue = event.target.value === '' ? '' : Number(event.target.value);
        onChange && onChange(newValue as any);
    };

    return (
        <StyledTextField
            {...props}
            ref={ref}
            fullWidth
            margin="normal"
            label={label}
            variant="outlined"
            type="number"
            size="small"
            value={value}
            onChange={handleChange}
            inputProps={{
                step: step,
                min: minValue,
                max: maxValue,
            }}
            InputProps={{
                ...props.InputProps,
                endAdornment: <BlueAdornment>{unit}</BlueAdornment>,
            }}
        />
    );
});

MuiNumberInput.displayName = 'MuiNumberInput';

export default MuiNumberInput;