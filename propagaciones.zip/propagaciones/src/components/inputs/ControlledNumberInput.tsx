import { Control, Controller, FieldValues, Path } from 'react-hook-form';
import MuiNumberInput, { MuiNumberInputProps } from './MuiNumberInput';

interface ControlledMuiNumberInputProps<T extends FieldValues> extends Omit<MuiNumberInputProps, 'name' | 'onChange' | 'value'> {
  name: Path<T>;
  control: Control<T>;
}

function ControlledNumberInput<T extends FieldValues>({
  name,
  control,
  ...props
}: ControlledMuiNumberInputProps<T>) {
  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <MuiNumberInput
          {...props}
          {...field}
          value={field.value ?? ''}
          onChange={(value) => {
            const numValue = !value ? null : Number(value);
            field.onChange(numValue);
          }}
          error={!!error}
          helperText={error?.message}
        />
      )}
    />
  );
}

export default ControlledNumberInput;