import { forwardRef } from 'react';
import { FormControl, InputLabel, Select, MenuItem, SelectProps } from '@mui/material';

interface Option {
    id: string | number;
    label: string;
}

interface MuiSelectorInputProps extends Omit<SelectProps, 'onChange'> {
    options: Option[];
    onChange: (value: string | number) => void;
}

const MuiSelectorInput = forwardRef<HTMLDivElement, MuiSelectorInputProps>(
    ({ options, label, onChange, ...props }, ref) => {
        return (
            <FormControl fullWidth margin="normal" size="small">
                <InputLabel id={`${props.name}-label`}>{label}</InputLabel>
                <Select
                    labelId={`${props.name}-label`}
                    label={label}
                    onChange={(e) => onChange(e.target.value as string | number)}
                    ref={ref}
                    {...props}
                >
                    {options.map((option) => (
                        <MenuItem key={option.id} value={option.id}>
                            {option.label}
                        </MenuItem>
                    ))}
                </Select>
            </FormControl>
        );
    }
);

MuiSelectorInput.displayName = 'MuiSelectorInput';

export default MuiSelectorInput;