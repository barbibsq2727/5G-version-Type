import React from 'react';
import { Card, CardContent, Typography, Box, Divider } from '@mui/material';
import { SignalCellular4Bar, WifiTethering, NetworkCell } from '@mui/icons-material';

interface PropagationResult {
    pathLoss: number;
    pathLossTotal: number;
    shadowfading: number;
}

interface PropagationResultsProps {
    propagationResult: PropagationResult | null;
}

const ResultItem: React.FC<{ label: string; value: number; icon: React.ReactNode }> = ({ label, value, icon }) => (
    <Box display="flex" alignItems="center" mb={2}>
        <Box mr={2}>{icon}</Box>
        <Box flexGrow={1}>
            <Typography variant="subtitle1" color="text.secondary">
                {label}
            </Typography>
            <Typography variant="h6" color="primary">
                {value.toFixed(4)} dB
            </Typography>
        </Box>
    </Box>
);

export default function PropagationResults({ propagationResult }: PropagationResultsProps) {
    if (!propagationResult) return null;

    return (
        <Box sx={{ mt: 4 }}>
            <Card elevation={3} sx={{ mt: 4, maxWidth: 600, mx: 'auto' }}>
                <CardContent>
                    <Typography variant="h5" gutterBottom align="center" color="text.primary">
                        Propagation Results
                    </Typography>
                    <Divider sx={{ my: 2 }} />
                    <Box display="flex" flexDirection="row" justifyContent={'space-between'} alignItems={'center'}>
                        <ResultItem
                            label="Path Loss Total"
                            value={propagationResult.pathLossTotal}
                            icon={<SignalCellular4Bar color="primary" />}
                        />
                        <ResultItem
                            label="Shadowfading"
                            value={propagationResult.shadowfading}
                            icon={<WifiTethering color="secondary" />}
                        />
                        <ResultItem
                            label="Path Loss"
                            value={propagationResult.pathLoss}
                            icon={<NetworkCell color="error" />}
                        />
                    </Box>
                </CardContent>
            </Card>
        </Box>
    );
}