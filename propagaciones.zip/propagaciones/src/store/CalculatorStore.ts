import { create, StateCreator } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import { LineOfSight, LossModel, Scenario, Tabulation } from '../models';

// Define the shape of your state
export interface PropagationState {
  scenario: Scenario | null;
  lossModel: LossModel | null;
  lineOfSight: LineOfSight | null;
  tabulation: Tabulation | null;
  frequency: number;
  frequencyLimits: { min: number; max: number };
  distance2DOut: number;
  distance2DOutLimits: { min: number; max: number };
  distance2DIn: number;
  distance2DInLimits: { min: number; max: number };
  heightBS: number;
  heightBSLimits: { min: number; max: number };
  heightUT: number;
  heightUTLimits: { min: number; max: number };
  buildingHeight?: number;
  buildingHeightLimits: { min: number; max: number };
  streetWidth?: number;
  streetWidthLimits: { min: number; max: number };
  variableFrequency?: number;
  variableFrequencyLimits: { min: number; max: number };
  variableDistance?: number;
  variableDistanceLimits: { min: number; max: number };
  propagationResult: {
    pathLoss: number;
    pathLossTotal: number;
    shadowfading: number;
  } | null;

  // Setters
  setScenario: (scenario: Scenario) => void;
  setLossModel: (lossModel: LossModel) => void;
  setTabulation: (tabulation: Tabulation) => void;
  setLineOfSight: (lineOfSight: LineOfSight) => void;
  setFrequency: (frequency: number) => void;
  setFrequencyLimits: (min: number, max: number) => void;
  setDistance2DOut: (distance2DOut: number) => void;
  setDistance2DOutLimits: (min: number, max: number) => void;
  setDistance2DIn: (distance2DIn: number) => void;
  setDistance2DInLimits: (min: number, max: number) => void;
  setHeightBS: (heightBS: number) => void;
  setHeightBSLimits: (min: number, max: number) => void;
  setHeightUT: (heightUT: number) => void;
  setHeightUTLimits: (min: number, max: number) => void;
  setBuildingHeight: (buildingHeight?: number) => void;
  setBuildingHeightLimits: (min: number, max: number) => void;
  setStreetWidth: (streetWidth?: number) => void;
  setStreetWidthLimits: (min: number, max: number) => void;
  setVariableFrequency: (variableFrequency?: number) => void;
  setVariableDistance: (variableDistance?: number) => void;
  setVariableFrequencyLimits: (min: number, max: number) => void;
  setVariableDistanceLimits: (min: number, max: number) => void;
  setPropagationValues: (values: Partial<
    Pick<
      PropagationState,
      | 'frequency'
      | 'distance2DOut'
      | 'distance2DIn'
      | 'heightBS'
      | 'heightUT'
      | 'buildingHeight'
      | 'streetWidth'
      | 'variableFrequency'
      | 'variableDistance'
    >
  >) => void;
  setPropagationResult: (result: PropagationState['propagationResult']) => void;
}

// Create the store with `devtools` and `persist` middleware
const createPropagationSlice: StateCreator<
  PropagationState,
  [],
  [],
  PropagationState
> = (set, get) => ({
  scenario: null,
  lossModel: null,
  lineOfSight: LineOfSight.LOS,
  tabulation: Tabulation.UNIC_VALUE,
  frequency: 0.5,
  frequencyLimits: { min: 0.5, max: 100 },
  distance2DOut: 10,
  distance2DOutLimits: { min: 1, max: 100 },
  distance2DIn: 10,
  distance2DInLimits: { min: 1, max: 50 },
  heightBS: 10,
  heightBSLimits: { min: 5, max: 50 },
  heightUT: 1,
  heightUTLimits: { min: 0.5, max: 2 },
  buildingHeight: undefined,
  buildingHeightLimits: { min: 3, max: 30 },
  streetWidth: undefined,
  streetWidthLimits: { min: 2, max: 20 },
  variableFrequency: undefined,
  variableFrequencyLimits: { min: 0.1, max: 10 },
  variableDistance: undefined,
  variableDistanceLimits: { min: 1, max: 1000 },
  propagationResult: null,

  setScenario: (scenario) => {
    if (scenario !== Scenario.RURAL_MACROCELL) {
      set(() => ({ scenario, buildingHeight: undefined, streetWidth: undefined }));
    } else {
      set(() => ({ scenario }));
    }
  },
  setTabulation: (tabulation) => {
    if (tabulation === Tabulation.UNIC_VALUE) {
      set(() => ({ tabulation, variableFrequency: undefined, variableDistance: undefined }));
    }
    if (tabulation === Tabulation.VARIABLE_FREQUENCY) {
      set(() => ({ tabulation, variableDistance: undefined }));
    }
    if (tabulation === Tabulation.VARIABLE_DISTANCE) {
      set(() => ({ tabulation, variableFrequency: undefined }));
    }
  },
  setLossModel: (lossModel) => set(() => ({ lossModel })),
  setLineOfSight: (lineOfSight) => set(() => ({ lineOfSight })),

  setFrequency: (frequency) => set(() => ({ frequency })),
  setFrequencyLimits: (min, max) => set(() => ({ frequencyLimits: { min, max } })),
  setDistance2DOut: (distance2DOut) => set(() => ({ distance2DOut })),
  setDistance2DOutLimits: (min, max) => set(() => ({ distance2DOutLimits: { min, max } })),
  setDistance2DIn: (distance2DIn) => set(() => ({ distance2DIn })),
  setDistance2DInLimits: (min, max) => set(() => ({ distance2DInLimits: { min, max } })),
  setHeightBS: (heightBS) => set(() => ({ heightBS })),
  setHeightBSLimits: (min, max) => set(() => ({ heightBSLimits: { min, max } })),
  setHeightUT: (heightUT) => set(() => ({ heightUT })),
  setHeightUTLimits: (min, max) => set(() => ({ heightUTLimits: { min, max } })),
  setBuildingHeight: (buildingHeight) => set(() => ({ buildingHeight })),
  setBuildingHeightLimits: (min, max) => set(() => ({ buildingHeightLimits: { min, max } })),
  setStreetWidth: (streetWidth) => set(() => ({ streetWidth })),
  setStreetWidthLimits: (min, max) => set(() => ({ streetWidthLimits: { min, max } })),
  setVariableFrequency: (variableFrequency) => set(() => ({ variableFrequency })),
  setVariableDistance: (variableDistance) => set(() => ({ variableDistance })),
  setVariableFrequencyLimits: (min, max) => set(() => ({ variableFrequencyLimits: { min, max } })),
  setVariableDistanceLimits: (min, max) => set(() => ({ variableDistanceLimits: { min, max } })),

  setPropagationValues: (values) => {
    const currentState = get();
    const updatedValues = {
      variableFrequency: values?.variableFrequency ?? currentState?.variableFrequency,
      variableDistance: values?.variableDistance ?? currentState?.variableDistance,
      frequency: values.frequency ?? currentState.frequency,
      distance2DOut: values.distance2DOut ?? currentState.distance2DOut,
      distance2DIn: values.distance2DIn ?? currentState.distance2DIn,
      heightBS: values.heightBS ?? currentState.heightBS,
      heightUT: values.heightUT ?? currentState.heightUT,
      buildingHeight: values.buildingHeight ?? currentState.buildingHeight,
      streetWidth: values.streetWidth ?? currentState.streetWidth,
    };
    set(updatedValues);
  },
  setPropagationResult: (result) => set(() => ({ propagationResult: result })),
});

export const usePropagationCalculatorStore = create<PropagationState>()(
  devtools(
    persist(createPropagationSlice, {
      name: 'propagation-calculator-store',
    })
  )
);
