const EscenarioPage = () => {
  return (
    <div>EscenarioPage</div>
  )
}

export default EscenarioPage