const LossModelPage = () => {
  return (
    <div>LossModelPage</div>
  )
}

export default LossModelPage