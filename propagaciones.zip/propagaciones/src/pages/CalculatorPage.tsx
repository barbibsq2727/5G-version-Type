const CalculatorPage = () => {
  return (
    <div>CalculatorPage</div>
  )
}

export default CalculatorPage