import { z } from 'zod';
import { LineOfSight, LossModel, Scenario, Tabulation } from '../models';
import { usePropagationCalculatorStore } from '../store/CalculatorStore';

export default function useValidationSchema() {
  const {
    scenario,
    tabulation,
    distance2DOutLimits,
    distance2DInLimits,
    heightBSLimits,
    heightUTLimits,
    buildingHeightLimits,
    streetWidthLimits,
    variableFrequencyLimits,
    variableDistanceLimits,
  } = usePropagationCalculatorStore();

  // Campos opcionales en función del estado del store
  const isRuralMacrocell = scenario === Scenario.RURAL_MACROCELL;
  const isUniqueValue = tabulation === Tabulation.UNIC_VALUE;
  const isTabulationVariableFrequency = tabulation === Tabulation.VARIABLE_FREQUENCY;
  const isTabulationVariableDistance = tabulation === Tabulation.VARIABLE_DISTANCE;

  return z.object({
    scenario: z.nativeEnum(Scenario, { errorMap: () => ({ message: 'Escenario inválido' }) }),
    lossModel: z.nativeEnum(LossModel, { errorMap: () => ({ message: 'Modelo de pérdidas inválido' }) }),
    tabulation: z.nativeEnum(Tabulation, { errorMap: () => ({ message: 'Tabulación inválida' }) }),
    lineOfSight: z.nativeEnum(LineOfSight, { errorMap: () => ({ message: 'Vista de línea inválida' }) }),

    // Campos que dependen del tabulation
    variableFrequency: z.preprocess(
      (value) => (typeof value === 'string' ? parseFloat(value) : value),
      z.number()
        .min(variableFrequencyLimits.min, `La frecuencia variable debe ser mayor o igual a ${variableFrequencyLimits.min}`)
        .max(variableFrequencyLimits.max, `La frecuencia variable debe ser menor o igual a ${variableFrequencyLimits.max}`)
        .optional()
        .refine(
          (val) => {
            if (isUniqueValue || isTabulationVariableDistance) {
              return true;
            }
            return isTabulationVariableFrequency ? val !== undefined : false
          },
          { message: 'Frecuencia variable requerida' }
        )
    ),
    variableDistance: z.preprocess(
      (value) => (typeof value === 'string' ? parseFloat(value) : value),
      z.number()
        .min(variableDistanceLimits.min, `La distancia variable debe ser mayor o igual a ${variableDistanceLimits.min}`)
        .max(variableDistanceLimits.max, `La distancia variable debe ser menor o igual a ${variableDistanceLimits.max}`)
        .optional()
        .refine(
          (val) => {
            if (isUniqueValue || isTabulationVariableFrequency) {
              return true;
            }
            return isTabulationVariableDistance ? val !== undefined : false
          },
          { message: 'Distancia variable requerida' }
        )
    ),

    // Campos fijos
    frequency: z.preprocess(
      (value) => (typeof value === 'string' ? parseFloat(value) : value),
      z.number().min(0.5, 'La frecuencia debe ser mayor o igual a 0.5 GHz').max(100, 'La frecuencia debe ser menor o igual a 100 GHz')
    ),
    distance2DOut: z.preprocess(
      (value) => (typeof value === 'string' ? parseFloat(value) : value),
      z.number()
        .min(distance2DOutLimits.min, `La distancia 2D exterior debe ser mayor o igual a ${distance2DOutLimits.min}`)
        .max(distance2DOutLimits.max, `La distancia 2D exterior debe ser menor o igual a ${distance2DOutLimits.max}`)
    ),
    distance2DIn: z.preprocess(
      (value) => (typeof value === 'string' ? parseFloat(value) : value),
      z.number()
        .min(distance2DInLimits.min, `La distancia 2D interior debe ser mayor o igual a ${distance2DInLimits.min}`)
        .max(distance2DInLimits.max, `La distancia 2D interior debe ser menor o igual a ${distance2DInLimits.max}`)
    ),
    heightBS: z.preprocess(
      (value) => (typeof value === 'string' ? parseFloat(value) : value),
      z.number()
        .min(heightBSLimits.min, `La altura de la estación base debe ser mayor o igual a ${heightBSLimits.min}`)
        .max(heightBSLimits.max, `La altura de la estación base debe ser menor o igual a ${heightBSLimits.max}`)
    ),
    heightUT: z.preprocess(
      (value) => (typeof value === 'string' ? parseFloat(value) : value),
      z.number()
        .min(heightUTLimits.min, `La altura de la unidad terminal debe ser mayor o igual a ${heightUTLimits.min}`)
        .max(heightUTLimits.max, `La altura de la unidad terminal debe ser menor o igual a ${heightUTLimits.max}`)
    ),

    // Campos opcionales cuando el escenario no es Rural Macrocell
    buildingHeight: z.preprocess(
      (value) => (typeof value === 'string' ? parseFloat(value) : value),
      z.number()
        .min(buildingHeightLimits.min, `La altura del edificio debe ser mayor o igual a ${buildingHeightLimits.min}`)
        .max(buildingHeightLimits.max, `La altura del edificio debe ser menor o igual a ${buildingHeightLimits.max}`)
        .optional()
        .refine(
          (val) => {
            if(!isRuralMacrocell) {
              return true;
            }
            return isRuralMacrocell ? val !== undefined : false
          },
          { message: 'Altura del edificio requerida' }
        )
    ),
    streetWidth: z.preprocess(
      (value) => (typeof value === 'string' ? parseFloat(value) : value),
      z.number()
        .min(streetWidthLimits.min, `El ancho de la calle debe ser mayor o igual a ${streetWidthLimits.min}`)
        .max(streetWidthLimits.max, `El ancho de la calle debe ser menor o igual a ${streetWidthLimits.max}`)
        .optional()
        .refine(
          (val) => {
            if(!isRuralMacrocell) {
              return true;
            }
            return isRuralMacrocell ? val !== undefined : false
          },
          { message: 'Ancho de la calle requerido' }
        )
    ),
  });
};

