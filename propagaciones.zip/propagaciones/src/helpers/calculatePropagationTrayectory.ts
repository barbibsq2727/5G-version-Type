import { LineOfSight, LossModel, Scenario } from '../models';
import { usePropagationCalculatorStore } from '../store/CalculatorStore';
import randomNormal from './randomNormal';

export function calculatePropagation() {
    const { scenario, lossModel, lineOfSight, frequency, distance2DOut, distance2DIn, heightBS, heightUT, buildingHeight, setPropagationResult } = usePropagationCalculatorStore.getState();

    if ( [distance2DOut, distance2DIn, frequency, heightBS, heightUT].some((val) => isNaN(parseFloat(String(val))))) {
        console.error('Por favor, ingrese valores válidos para todos los campos.');
        return;
    }

    const d2D = parseFloat(String(distance2DOut));
    const d3D = Math.sqrt((parseFloat(String(distance2DOut)) + parseFloat(String(distance2DIn))) ** 2 + (parseFloat(String(heightBS)) - parseFloat(String(heightUT))) ** 2);
    const d_BP = (2 * Math.PI * parseFloat(String(heightBS)) * parseFloat(String(heightUT)) * parseFloat(String(frequency * 10 ** 9))) / (3.0 * 10 ** 8);
    const d_BP2 = (4 * parseFloat(String(heightBS)) * parseFloat(String(heightUT)) * parseFloat(String(frequency * 10 ** 9))) / (3.0 * 10 ** 8);
    const sigma_p_bajas = 4.4;
    const sigma_p_altas = 4.4;
    const shadowfading_bajas = randomNormal(0, (sigma_p_bajas ** 2));
    const shadowfading_altas = randomNormal(0, (sigma_p_altas ** 2));
    const minFunc = (a: number, b: number) => Math.min(a, b);

    let PL1: number, PL2: number, PL_b: number | null, PL: number | null, shadowfading: number;

    const scenarioLossModelLOS = `${scenario}-${lossModel}-${lineOfSight}`;

    switch (scenarioLossModelLOS) {
        case `${Scenario.RURAL_MACROCELL}-${LossModel.LOW_LOSSES}-${LineOfSight.LOS}`:
            // Fórmulas para Escenario Rural Macrocell, Pérdidas Bajas, LOS
            PL1 = 20 * Math.log10(40 * Math.PI * d3D * frequency / 3) + minFunc(0.03 * Math.pow(buildingHeight || 0, 1.72), 10) * Math.log10(d3D)
                - minFunc(0.044 * Math.pow(buildingHeight || 0, 1.72), 14.77) + 0.002 * Math.log10(buildingHeight || 1) * d3D;

            PL2 = PL1 + 40 * Math.log10(d3D / d_BP);

            PL_b = (d2D >= 10 && d2D <= d_BP) ? PL1 : (d2D > d_BP && d2D <= 10000) ? PL2 : null;

            const PL_tw = 5 - 10 * Math.log10(0.3 * 10 ** (-(2 + (0.2 * frequency)) / 10) + 0.7 * 10 ** (-(5 + (4 * frequency)) / 10));
            const PL_in = 0.5 * parseFloat(String(distance2DIn));
            PL = PL_b ? PL_b + PL_tw + PL_in + shadowfading_bajas : null;
            shadowfading = shadowfading_bajas;
            break;

        case `${Scenario.RURAL_MACROCELL}-${LossModel.HIGH_LOSSES}-${LineOfSight.LOS}`:
            // Fórmulas para Escenario Rural Macrocell, Pérdidas Altas, LOS
            PL1 = 20 * Math.log10(40 * Math.PI * d3D * frequency / 3) + minFunc(0.03 * Math.pow(buildingHeight || 0, 1.72), 10) * Math.log10(d3D)
                - minFunc(0.044 * Math.pow(buildingHeight || 0, 1.72), 14.77) + 0.002 * Math.log10(buildingHeight || 1) * d3D;

            PL2 = PL1 + 40 * Math.log10(d3D / d_BP);

            PL_b = (d2D >= 10 && d2D <= d_BP) ? PL1 : (d2D > d_BP && d2D <= 10000) ? PL2 : null;

            const PL_tw_altas = 5 - 10 * Math.log10(0.7 * 10 ** (-(23 + (0.3 * frequency)) / 10) + 0.3 * 10 ** (-(5 + (4 * frequency)) / 10));
            const PL_in_altas = 0.5 * parseFloat(String(distance2DIn));
            PL = PL_b ? PL_b + PL_tw_altas + PL_in_altas + shadowfading_altas : null;
            shadowfading = shadowfading_altas;
            break;

        case `${Scenario.URBAN_MACROCELL}-${LossModel.LOW_LOSSES}-${LineOfSight.LOS}`:
            // Fórmulas para Escenario Urban Macrocell, Pérdidas Bajas, LOS
            PL1 = 28.0 + 22 * Math.log10(d3D) + 20 * Math.log10(frequency);
            PL2 = 28.0 + 40 * Math.log10(d3D) + 20 * Math.log10(frequency) - 9 * Math.log10((d_BP ** 2) + ((heightBS - heightUT) ** 2));
            PL_b = (d2D >= 10 && d2D <= d_BP2) ? PL1 : (d2D > d_BP2 && d2D <= 5000) ? PL2 : null;

            const PL_tw_2bajas = 5 - 10 * Math.log10(0.3 * 10 ** (-(2 + (0.2 * frequency)) / 10) + 0.7 * 10 ** (-(5 + (4 * frequency)) / 10));
            const PL_in_2bajas = 0.5 * parseFloat(String(distance2DIn));
            PL = PL_b ? PL_b + PL_tw_2bajas + PL_in_2bajas + shadowfading_bajas : null;
            shadowfading = shadowfading_bajas;
            break;

        case `${Scenario.URBAN_MACROCELL}-${LossModel.HIGH_LOSSES}-${LineOfSight.LOS}`:
            // Fórmulas para Escenario Urban Macrocell, Pérdidas Altas, LOS
            PL1 = 28.0 + 22 * Math.log10(d3D) + 20 * Math.log10(frequency);
            PL2 = 28.0 + 40 * Math.log10(d3D) + 20 * Math.log10(frequency) - 9 * Math.log10((d_BP ** 2) + ((heightBS - heightUT) ** 2));
            PL_b = (d2D >= 10 && d2D <= d_BP2) ? PL1 : (d2D > d_BP2 && d2D <= 5000) ? PL2 : null;

            const PL_tw_2altas = 5 - 10 * Math.log10(0.7 * 10 ** (-(23 + (0.3 * frequency)) / 10) + 0.3 * 10 ** (-(5 + (4 * frequency)) / 10));
            const PL_in_2altas = 0.5 * parseFloat(String(distance2DIn));
            PL = PL_b ? PL_b + PL_tw_2altas + PL_in_2altas + shadowfading_altas : null;
            shadowfading = shadowfading_altas;
            break;

        case `${Scenario.URBAN_MICROCELL}-${LossModel.LOW_LOSSES}-${LineOfSight.LOS}`:
            // Fórmulas para Escenario Urban Microcell, Pérdidas Bajas, LOS
            PL1 = 32.4 + 21 * Math.log10(d3D) + 20 * Math.log10(frequency);
            PL2 = 32.4 + 40 * Math.log10(d3D) + 20 * Math.log10(frequency) - 9.5 * Math.log10((d_BP ** 2) + ((heightBS - heightUT) ** 2));
            PL_b = (d2D >= 10 && d2D <= d_BP2) ? PL1 : (d2D > d_BP2 && d2D <= 5000) ? PL2 : null;

            const PL_tw_3bajas = 5 - 10 * Math.log10(0.3 * 10 ** (-(2 + (0.2 * frequency)) / 10) + 0.7 * 10 ** (-(5 + (4 * frequency)) / 10));
            const PL_in_3bajas = 0.5 * parseFloat(String(distance2DIn));
            PL = PL_b ? PL_b + PL_tw_3bajas + PL_in_3bajas + shadowfading_bajas : null;
            shadowfading = shadowfading_bajas;
            break;

        case `${Scenario.URBAN_MICROCELL}-${LossModel.HIGH_LOSSES}-${LineOfSight.LOS}`:
            // Fórmulas para Escenario Urban Microcell, Pérdidas Altas, LOS
            PL1 = 32.4 + 21 * Math.log10(d3D) + 20 * Math.log10(frequency);
            PL2 = 32.4 + 40 * Math.log10(d3D) + 20 * Math.log10(frequency) - 9.5 * Math.log10((d_BP ** 2) + ((heightBS - heightUT) ** 2));
            PL_b = (d2D >= 10 && d2D <= d_BP2) ? PL1 : (d2D > d_BP2 && d2D <= 5000) ? PL2 : null;

            const PL_tw_3altas = 5 - 10 * Math.log10(0.7 * 10 ** (-(23 + (0.3 * frequency)) / 10) + 0.3 * 10 ** (-(5 + (4 * frequency)) / 10));
            const PL_in_3altas = 0.5 * parseFloat(String(distance2DIn));
            PL = PL_b ? PL_b + PL_tw_3altas + PL_in_3altas + shadowfading_altas : null;
            shadowfading = shadowfading_altas;
            break;

        case `${Scenario.OFFICE_INDOOR}-${LossModel.LOW_LOSSES}-${LineOfSight.LOS}`:
        case `${Scenario.OFFICE_INDOOR}-${LossModel.HIGH_LOSSES}-${LineOfSight.LOS}`:
            // Fórmulas para Escenario Office Indoor, Pérdidas Bajas y Altas, LOS
            PL_b = 32.4 + 17.3 * Math.log10(d3D) + 20 * Math.log10(frequency);

            const PL_tw_4 = 5 - 10 * Math.log10(0.3 * 10 ** (-(2 + (0.2 * frequency)) / 10) + 0.7 * 10 ** (-(5 + (4 * frequency)) / 10));
            const PL_in_4 = 0.5 * parseFloat(String(distance2DIn));
            PL = PL_b + PL_tw_4 + PL_in_4 + (lossModel === LossModel.LOW_LOSSES ? shadowfading_bajas : shadowfading_altas);
            shadowfading = lossModel === LossModel.LOW_LOSSES ? shadowfading_bajas : shadowfading_altas;
            break;

        default:
            console.error('Combinación de escenario, modelo de pérdidas y línea de vista no soportada');
            return;
    }

    if (PL !== null) {
        setPropagationResult({
            pathLoss: PL,
            pathLossTotal: PL_b || 0,
            shadowfading: shadowfading
        });
    } else {
        console.error('No se pudo calcular la pérdida de trayecto para la combinación seleccionada.');
    }
}