export enum Tabulation {
    UNIC_VALUE = 'unic-value',
    VARIABLE_FREQUENCY = 'variable-frequency',
    VARIABLE_DISTANCE = 'variable-distance',
}