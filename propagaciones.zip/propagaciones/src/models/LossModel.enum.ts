export enum LossModel {
    LOW_LOSSES = 'low-losses',
    HIGH_LOSSES = 'high-losses',
}