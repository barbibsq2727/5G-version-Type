export enum LineOfSight {
    LOS = 'los',
    NLOS = 'nlos',
}