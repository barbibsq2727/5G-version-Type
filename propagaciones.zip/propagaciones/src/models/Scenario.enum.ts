export enum Scenario {
    RURAL_MACROCELL = 'rural-macrocell',
    URBAN_MACROCELL = 'urban-macrocell',
    URBAN_MICROCELL = 'urban-microcell',
    OFFICE_INDOOR = 'office-indoor',
}
