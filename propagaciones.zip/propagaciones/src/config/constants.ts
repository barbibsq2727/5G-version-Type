import { LineOfSight, LossModel, Scenario, Tabulation } from "../models";

export const ESCENARIOS = [
    { id: Scenario.RURAL_MACROCELL, label: 'Macrocelda Rural' },
    { id: Scenario.URBAN_MACROCELL, label: 'Macrocelda Urbana' },
    { id: Scenario.URBAN_MICROCELL, label: 'Microcelda Urbana' },
    { id: Scenario.OFFICE_INDOOR, label: 'Interior Oficina' },
];

export const LOSS_MODELS = [
    { id: LossModel.LOW_LOSSES, label: 'Bajas Pérdidas' },
    { id: LossModel.HIGH_LOSSES, label: 'Altas Pérdidas' },
];

export const TABULATIONS = [
    { id: Tabulation.UNIC_VALUE, label: 'Valor Único' },
    { id: Tabulation.VARIABLE_DISTANCE, label: 'Distancia Variable' },
    { id: Tabulation.VARIABLE_FREQUENCY, label: 'Frecuencia Variable' },
];

export const LINE_OF_SIGHTS = [
    { id: LineOfSight.LOS, label: 'LOS' },
    { id: LineOfSight.NLOS, label: 'NLOS' },
];